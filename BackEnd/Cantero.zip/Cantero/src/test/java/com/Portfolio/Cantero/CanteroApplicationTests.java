package com.Portfolio.Cantero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanteroApplicationTests {

	@Test
	void contextLoads() {
	}

}
