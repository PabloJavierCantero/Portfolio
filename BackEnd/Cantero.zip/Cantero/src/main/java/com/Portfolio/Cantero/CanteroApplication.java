package com.Portfolio.Cantero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CanteroApplication {

	public static void main(String[] args) {
		SpringApplication.run(CanteroApplication.class, args);
	}

}
